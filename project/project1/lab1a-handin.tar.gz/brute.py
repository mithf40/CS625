#!/usr/bin/python

import sys, socket, time

host = "localhost"
port = 8080

l = 100

while(l<3000):
	sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	sock.connect((host,port))
	req = "GET / HTTP/1.0\r\nHTTP_" + l*"m" + ": foo\r\n\r\n"
	sock.send(req)
	data = sock.recv(1024)
	sock.close()
	time.sleep(2)
	print("Length Sent: "+str(l))
	l += 100

