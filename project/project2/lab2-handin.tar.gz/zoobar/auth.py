from zoodb import *
from debug import *
from base64 import b64encode

import pbkdf2
import hashlib
import random

def newtoken(db, person):
    hashinput = "%s%.10f" % (person.password, random.random())
    person.token = hashlib.md5(hashinput).hexdigest()
    db.commit()
    return person.token

def login(username, password):
    db = cred_setup()
    person = db.query(Cred).get(username)
    if not person:
        return None
    salt = person.salt
    password = pbkdf2.PBKDF2(password,salt).hexread(32)
    if person.password == password:
        return newtoken(db, person)
    else:
        return None

def register(username, password):
    person_db = person_setup()
    cred_db = cred_setup()

    person = person_db.query(Person).get(username)
    if person:
        return None
    
    salt = b64encode(os.urandom(8)).decode('utf-8')
    person = Person()
    newperson = Cred()
    
    person.username = username
    newperson.username = username
    newperson.salt = salt

    password = pbkdf2.PBKDF2(password,salt).hexread(32)
    newperson.password = password
    cred_db.add(newperson)
    person_db.add(person)

    person_db.commit()
    cred_db.commit()

    return newtoken(cred_db, newperson)

def check_token(username, token):
    db = cred_setup()
    person = db.query(Cred).get(username)
    if person and person.token == token:
        return True
    else:
        return False

def getToken(username):
    cred_db = cred_setup()
    user = cred_db.query(Cred).get(username)
    if not user:
        raise ValueError("Invalid User")
    return user.token
