from debug import *
from zoodb import *
import rpclib

def login(username, password):
    ## Fill in code here.
    with rpclib.client_connect('/authsvc/sock') as rpc:
        temp = rpc.call('login',user=username, passd=password)
        return temp


def register(username, password):
    ## Fill in code here.
    with rpclib.client_connect('/authsvc/sock') as rpc:
        temp = rpc.call('register', user=username, passd=password)
        return temp

def check_token(username, token):
    ## Fill in code here.
    with rpclib.client_connect('/authsvc/sock') as rpc:
        temp = rpc.call('check_token', user=username, token=token)
        return temp

def getToken(username):
    with rpclib.client_connect('/authsvc/sock') as rpc:
        temp = rpc.call('getToken', username=username)
        return temp
