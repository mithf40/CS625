from debug import *
from zoodb import *
import rpclib

def balance(username):
    with rpclib.client_connect('/banksvc/sock') as rpc:
        temp = rpc.call('balance', username=username)
        return temp

def register(username):
    with rpclib.client_connect('/banksvc/sock') as rpc:
        temp = rpc.call('register', username=username)
        return temp

def transfer(sender, recipient, zoobars, token):
    try:
        with rpclib.client_connect('/banksvc/sock') as rpc:
            temp = rpc.call('transfer', sender=sender, recipient=recipient, zoobars=zoobars, token=token)
            return temp
    except Exception:
        return ValueError("Error")

def get_log(username):
    with rpclib.client_connect('/banksvc/sock') as rpc:
        temp = rpc.call('get_log', username=username)
        return temp


